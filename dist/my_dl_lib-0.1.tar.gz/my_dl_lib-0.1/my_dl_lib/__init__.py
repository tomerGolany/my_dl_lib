from .generic_neural_network import GenericNeuralNetwork
from .generic_lstm import GenericLSTM
from .generic_dataset import GenericDataSetIterator

# from .generic_gan.gan import GenericGAN
# from .generic_gan.generator import GenericGenerator
# from .generic_gan.discriminator import GenericDiscriminator