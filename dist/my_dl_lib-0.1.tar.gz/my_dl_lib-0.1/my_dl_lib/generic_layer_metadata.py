
class GenericLayerMetaData:

    def __init__(self, layer_type='fully_connected', filter_metadata=None):
        pass